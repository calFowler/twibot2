//config.js
/** TWITTER APP CONFIGURATION
 * consumer_key
 * consumer_secret
 * access_token
 * access_token_secret
 */
module.exports = {
  consumer_key: 'VdNcklswckKVrL2lXmIp6WvGD',  
  consumer_secret: 'eZ4WJVnjsprrqsehkw85jzoOUDqxMVOoyq9wpGvmdLCO8d6NAw',
  access_token: '18046934-FlMwkkNH5MfQdVQ9hIhYbjR0FMYyj0Qw1ygGsR8bA',  
  access_token_secret: 'x5OpdOp7LsRrPjkl3aVfwaQ97jc3aunIw7oohDYOUpe6L'
}